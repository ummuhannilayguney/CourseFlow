const API = {
  async request(path, { method = "GET", body = null, auth = true } = {}) {
    const headers = { "Content-Type": "application/json" };
    const token = localStorage.getItem("token");
    if (auth && token) headers["Authorization"] = "Bearer " + token;

    let res;
    try {
      res = await fetch(path, {
        method,
        headers,
        body: body ? JSON.stringify(body) : null
      });
    } catch (err) {
      throw new Error("Ağ hatası: " + err.message);
    }

    let data;
    try {
      data = await res.json();
    } catch {
      data = {};
    }

    if (!res.ok) {
      // Hata mesajını Türkçeleştir
      const errorMap = {
        "BAD_REQUEST": "Geçersiz istek",
        "UNAUTHORIZED": "Yetkilendirme hatası",
        "FORBIDDEN": "Erişim reddedildi",
        "NOT_FOUND": "Bulunamadı",
        "CONFLICT": "Çakışma",
        "INTERNAL_SERVER_ERROR": "Sunucu hatası",
        "BAD_SCHEDULE": "Geçersiz ders zamanı formatı"
      };
      
      const errorMsg = errorMap[data?.error] || data?.error || "İstek başarısız";
      const detail = data?.detail ? ` (${data.detail})` : "";
      throw new Error(errorMsg + detail);
    }
    return data;
  },

  loginAdmin(password) {
    return this.request("/api/auth/login", { method: "POST", body: { role: "admin", password }, auth: false });
  },

  loginStudent(id, password) {
    return this.request("/api/auth/login", { method: "POST", body: { role: "student", id, password }, auth: false });
  },

  logout() {
    return this.request("/api/auth/logout", { method: "POST" });
  },

  listCourses(query = "") {
    return this.request("/api/courses?query=" + encodeURIComponent(query), { auth: false });
  },

  getMe() {
    return this.request("/api/students/me", { method: "GET" });
  },

  saveCart(cart) {
    return this.request("/api/students/me/cart", { method: "POST", body: { cart } });
  },

  addWaitlist(courseCode) {
    return this.request("/api/students/me/waitlist", { method: "POST", body: { courseCode } });
  },

  getMyWaitlist() {
    return this.request("/api/students/me/waitlist", { method: "GET" });
  },

  adminCourses() {
    return this.request("/api/admin/courses", { method: "GET" });
  },

  adminAddCourse(course) {
    return this.request("/api/admin/courses", { method: "POST", body: course });
  },

  adminDeleteCourse(code) {
    return this.request("/api/admin/courses/" + encodeURIComponent(code), { method: "DELETE" });
  },

  runSimulation() {
    return this.request("/api/simulate/run", { method: "POST" });
  },

  resetSimulation() {
    return this.request("/api/simulate/reset", { method: "POST" });
  },

  lastSimulation() {
    return this.request("/api/simulate/last", { method: "GET", auth: false });
  }
};

window.API = API;
