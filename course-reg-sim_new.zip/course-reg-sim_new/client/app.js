function setActiveNav() {
  const here = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".navlinks a").forEach(a => {
    const href = a.getAttribute("href");
    if (href === here) a.classList.add("active");
  });
}

async function logout() {
  try {
    await API.logout();
  } catch (e) {
    console.warn("Logout API call failed:", e);
  }
  localStorage.removeItem("token");
  localStorage.removeItem("role");
  localStorage.removeItem("studentId");
  location.href = "/login.html";
}

function renderUserPill() {
  const role = localStorage.getItem("role");
  const pill = document.getElementById("userPill");
  if (!pill) return;

  if (!role) {
    pill.innerHTML = `<span class="small">Giriş yapılmadı</span>`;
    return;
  }

  const label = role === "admin"
    ? "Admin"
    : `Öğrenci: ${localStorage.getItem("studentId") || ""}`;

  pill.innerHTML = `
    <span>${label}</span>
    <button class="btn btn-secondary" style="padding:8px 10px; border-radius:999px;" id="logoutBtn">Çıkış</button>
  `;
  document.getElementById("logoutBtn").addEventListener("click", logout);
}

window.addEventListener("DOMContentLoaded", () => {
  setActiveNav();
  renderUserPill();

  const page = document.body.getAttribute("data-page");
  if (page === "login") initLogin();
  if (page === "dashboard") initDashboard();
  if (page === "catalog") initCatalog();
  if (page === "cart") initCart();
  if (page === "simulate") initSimulate();
  if (page === "admin") initAdmin();
  if (page === "transcript") initTranscript();
  if (page === "waitlist") initWaitlist();
});

async function initLogin() {
  const adminForm = document.getElementById("adminLoginForm");
  const studentForm = document.getElementById("studentLoginForm");

  adminForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const password = document.getElementById("adminPassword").value;
    try {
      const r = await API.loginAdmin(password);
      localStorage.setItem("token", r.token);
      localStorage.setItem("role", "admin");
      location.href = "/dashboard.html";
    } catch (err) {
      alert("Admin giriş hatası: " + err.message);
    }
  });

  studentForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const id = document.getElementById("studentId").value;
    const password = document.getElementById("studentPassword").value;
    try {
      const r = await API.loginStudent(id, password);
      localStorage.setItem("token", r.token);
      localStorage.setItem("role", "student");
      localStorage.setItem("studentId", r.studentId || id);
      location.href = "/dashboard.html";
    } catch (err) {
      alert("Öğrenci giriş hatası: " + err.message);
    }
  });
}

async function initDashboard() {
  const metricsEl = document.getElementById("metrics");
  const coursesEl = document.getElementById("topCourses");
  const studentResEl = document.getElementById("studentResult");
  const adminReportEl = document.getElementById("adminReport");

  const role = localStorage.getItem("role");
  const meId = localStorage.getItem("studentId");

  const last = await API.lastSimulation();
  const result = last.result;

  if (!result) {
    metricsEl.innerHTML = `<div class="small">Henüz simülasyon çalıştırılmadı. Admin → Simülasyon ekranından başlat.</div>`;
    coursesEl.innerHTML = `<div class="small">Simülasyon sonrası doluluklar burada görünecek.</div>`;
    return;
  }

  const m = result.metrics;
  metricsEl.innerHTML = `
    <div class="grid">
      ${kpi("Kontenjanı dolan ders", m.fullCoursesCount)}
      ${kpi("Kontenjan yüzünden reddedilen", m.rejectedByCapacity)}
      ${kpi("Waitlist'e alınan", m.waitlistedCount || 0)}
      ${kpi("Çakışma yüzünden reddedilen", m.rejectedByConflict)}
      ${kpi("Çakışmada düşen ders", m.droppedDueToConflict || 0)}
      ${kpi("Ön şart yüzünden reddedilen", m.rejectedByPrereq)}
      ${kpi("Ortalama alınan ders", m.avgApprovedPerStudent)}
    </div>
  `;

  const top = result.courses
    .slice()
    .sort((a, b) => b.fillRate - a.fillRate)
    .slice(0, 8);

  coursesEl.innerHTML = top.map(c => courseRow(c)).join("");

  // ===== Per-student outcome =====
  if (studentResEl) {
    if (role === "student") {
      const mine = (result.students || []).find(s => s.id === meId);
      studentResEl.innerHTML = mine
        ? renderStudentOutcome(mine)
        : `<div class="card"><div style="font-weight:900">Kayıt Sonucun</div><div class="small mt12">Bu öğrenci için simülasyon sonucu bulunamadı.</div></div>`;
    } else {
      studentResEl.innerHTML = "";
    }
  }

  // ===== Admin: detailed report =====
  if (adminReportEl) {
    if (role === "admin") {
      adminReportEl.innerHTML = renderAdminReport(result);

      const input = document.getElementById("reportStudentId");
      const btn = document.getElementById("reportFindBtn");
      const out = document.getElementById("reportOut");

      const renderById = () => {
        const id = (input.value || "").trim();
        const r = (result.students || []).find(s => s.id === id);
        out.innerHTML = r
          ? renderStudentOutcome(r)
          : `<div class="card"><div class="small">${id ? `"${id}"` : "Bu"} öğrenci için sonuç bulunamadı.</div></div>`;
      };

      btn.addEventListener("click", renderById);
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") renderById(); });
    } else {
      adminReportEl.innerHTML = "";
    }
  }
}

function renderAdminReport(simResult) {
  const students = (simResult.students || []).slice();
  // show top 30 by approved count
  students.sort((a, b) => (b.approved?.length || 0) - (a.approved?.length || 0));
  const top = students.slice(0, 30);

  return `
    <div class="card">
      <div style="font-weight:900; font-size:18px;">Detaylı sonuç raporu</div>
      <div class="small mt12">Admin için: “kim hangi dersleri aldı / alamadı / neden” görünümü.</div>

      <div class="mt12" style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
        <input id="reportStudentId" class="input" placeholder="Öğrenci ID (örn. S0001)" style="max-width:220px;"/>
        <button id="reportFindBtn" class="btn btn-secondary">Bul</button>
      </div>

      <div id="reportOut" class="mt12"></div>

      <div class="mt18" style="font-weight:900;">Örnek: En çok ders alan ilk 30 öğrenci</div>
      <div class="small" style="color: var(--muted);">Not: Bu sadece hızlı bir görünüm. Arama kutusuyla herhangi bir öğrenciyi açabilirsin.</div>

      <div class="mt12" style="overflow:auto;">
        <table class="table">
          <thead><tr><th>Öğrenci</th><th>Sınıf</th><th>GPA</th><th>Onay</th><th>Red</th></tr></thead>
          <tbody>
            ${top.map(s => `
              <tr>
                <td style="font-weight:900">${s.id}</td>
                <td>${s.classYear}</td>
                <td>${s.gpa}</td>
                <td>${(s.approved || []).length}</td>
                <td>${(s.rejected || []).length}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function renderStudentOutcome(s) {
  const approved = s.approved || [];
  const rejected = s.rejected || [];

  return `
    <div class="card">
      <div class="spread">
        <div>
          <div style="font-weight:900; font-size:18px;">Kayıt sonucu · ${s.id}</div>
          <div class="small">Sınıf: ${s.classYear} · GPA: ${s.gpa} · Kalan ders: ${s.remainingCourses}</div>
        </div>
        <span class="badge">Onay: ${approved.length}</span>
      </div>

      <div class="mt12" style="font-weight:900;">Onaylanan dersler</div>
      <div class="small mt6">${approved.length ? approved.map(x => `<span class="badge" style="margin-right:6px;">${x}</span>`).join("") : "—"}</div>

      <div class="mt18" style="font-weight:900;">Alınamayan / düşen dersler</div>
      ${rejected.length ? `
        <div class="mt12" style="overflow:auto;">
          <table class="table">
            <thead><tr><th>Ders</th><th>Gerekçe</th><th>Detay</th></tr></thead>
            <tbody>
              ${rejected.map(r => `
                <tr>
                  <td style="font-weight:900">${r.code}</td>
                  <td>${reasonLabel(r.reason)}</td>
                  <td class="small">${reasonDetail(r)}</td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      ` : `<div class="small mt12">Reddedilen ders yok.</div>`}
    </div>
  `;
}

function reasonLabel(reason) {
  const map = {
    COURSE_NOT_FOUND: "Ders bulunamadı",
    PREREQ_MISSING: "Ön şart eksik",
    CONFLICT: "Ders çakışması",
    CONFLICT_REQUIRED_REQUIRED: "Zorunlu–zorunlu çakışması (sıra kuralı)",
    DROPPED_DUE_TO_CONFLICT: "Çakışma çözümü: ders düşürüldü",
    CAPACITY_FULL: "Kontenjan dolu",
    CAPACITY_FULL_WAITLISTED: "Kontenjan dolu: waitlist'e alındı"
  };
  return map[reason] || reason;
}

function reasonDetail(r) {
  if (!r) return "";
  if (r.reason === "PREREQ_MISSING" && r.detail) {
    const missing = (r.detail.missing || []).join(", ");
    const paths = (r.detail.paths || []).slice(0, 3).map(p => p.path.join(" → ")).join(" | ");
    return `${missing ? `Eksik: ${missing}. ` : ""}${paths ? `Örnek zincir: ${paths}` : ""}`;
  }
  if ((r.reason === "CONFLICT" || r.reason === "CONFLICT_REQUIRED_REQUIRED") && r.detail) {
    const withC = r.detail.with ? `Çakışan: ${r.detail.with}. ` : "";
    const conf = (r.detail.conflicts || []).map(c => `${c.day} ${c.range}`).join(", ");
    return `${withC}${conf ? `Zaman: ${conf}` : ""}`;
  }
  if (r.reason === "DROPPED_DUE_TO_CONFLICT" && r.detail) {
    return r.detail.replacedBy ? `Yerine: ${r.detail.replacedBy}` : "";
  }
  if (r.reason === "CAPACITY_FULL" && r.detail?.canWaitlist) {
    return "İstersen waitlist'e eklenebilir (katalog ekranından veya butonla).";
  }
  return "";
}

function kpi(label, value) {
  return `
  <div class="card" style="grid-column: span 4;">
    <div class="kpi">
      <div class="value">${value}</div>
      <div class="label">${label}</div>
    </div>
  </div>`;
}

function courseRow(c) {
  const pct = Math.round((c.fillRate || 0) * 100);
  return `
  <div class="card mt12">
    <div class="spread">
      <div>
        <div style="font-weight:900">${c.code} · ${c.name}</div>
        <div class="small">${c.dept} · Kontenjan ${c.capacity} · Kayıt ${c.enrolled} · Waitlist ${c.waitlist}</div>
      </div>
      <span class="badge">%${pct}</span>
    </div>
    <div class="progress mt12"><div style="width:${pct}%"></div></div>
  </div>`;
}

async function initCatalog() {
  const q = document.getElementById("q");
  const list = document.getElementById("courseList");

  async function load() {
    const data = await API.listCourses(q.value);
    list.innerHTML = data.courses.map(c => {
      const pct = c.capacity ? Math.round((c.enrolled / c.capacity) * 100) : 0;
      const isFull = c.enrolled >= c.capacity;
      const prereqStr = c.prereqs?.length ? c.prereqs.join(", ") : "Yok";
      const role = localStorage.getItem("role");
      
      return `
      <div class="card mt12">
        <div class="spread">
          <div>
            <div style="font-weight:900">${c.code} · ${c.name}</div>
            <div class="small">${c.dept}</div>
            <div class="small">Saat: ${c.scheduleStrings.join(" + ")}</div>
            <div class="small">Ön şart: ${prereqStr}</div>
          </div>
          <div style="text-align:right;">
            <span class="badge">${isFull ? "🔴 DOLU" : "🟢 " + c.enrolled + "/" + c.capacity}</span>
            ${c.waitlist > 0 ? `<div class="small">⏳ Waitlist: ${c.waitlist}</div>` : ""}
          </div>
        </div>
        <div class="progress mt12"><div style="width:${pct}%;"></div></div>
        ${role === "student" ? `
          <div class="mt12">
            ${isFull ? `
              <button class="btn btn-secondary waitBtn" data-code="${c.code}" style="font-size:13px;">⏳ Waitlist'e Ekle</button>
            ` : `
              <button class="btn addCartBtn" data-code="${c.code}" style="font-size:13px;">➕ Sepete Ekle</button>
            `}
          </div>
        ` : ""}
      </div>`;
    }).join("");

    // Sepete ekleme butonları
    list.querySelectorAll(".addCartBtn").forEach(b => {
      b.addEventListener("click", async () => {
        const code = b.dataset.code;
        try {
          // Get current cart
          const me = await API.getMe();
          const cart = me.student.cart || [];
          
          // Check if already in cart
          if (cart.some(item => item.code === code)) {
            alert(`${code} zaten sepetinde var.`);
            return;
          }
          
          // Add to cart
          cart.push({ code, required: false, rank: cart.length });
          
          // Save
          await API.saveCart(cart);
          alert(`${code} sepete eklendi.`);
        } catch (err) {
          alert("Hata: " + err.message);
        }
      });
    });

    // Waitlist'e ekleme butonları
    list.querySelectorAll(".waitBtn").forEach(b => {
      b.addEventListener("click", async () => {
        const code = b.dataset.code;
        try {
          const resp = await API.addWaitlist(code);
          
          // Get course name
          const courseItem = b.closest(".courseItem");
          const courseName = courseItem?.querySelector(".code")?.textContent || code;
          
          // Show UI message
          const messageEl = document.getElementById("searchMessage");
          if (messageEl) {
            messageEl.innerHTML = `
              <div style="background: #d4edda; border: 1px solid #c3e6cb; padding: 8px; border-radius: 4px; margin-bottom: 12px; color: #155724;">
                ✅ <strong>${code}</strong> waitlist'ine eklendi. Simülasyonda kontenjan boşalırsa otomatik kaydolacaksınız.
              </div>
            `;
            setTimeout(() => {
              messageEl.innerHTML = "";
            }, 4000);
          }
        } catch (err) {
          const messageEl = document.getElementById("searchMessage");
          if (messageEl) {
            messageEl.innerHTML = `
              <div style="background: #f8d7da; border: 1px solid #f5c6cb; padding: 8px; border-radius: 4px; margin-bottom: 12px; color: #721c24;">
                ❌ Hata: ${err.message}
              </div>
            `;
          }
        }
      });
    });
  }

  document.getElementById("searchBtn").addEventListener("click", load);
  q.addEventListener("keydown", (e) => { if (e.key === "Enter") load(); });
  await load();
}

async function initCart() {
  const role = localStorage.getItem("role");
  if (role !== "student") {
    document.getElementById("cartRoot").innerHTML = `<div class="card">Bu sayfa sadece öğrenci içindir. <a href="/login.html">Giriş yap</a></div>`;
    return;
  }

  const me = await API.getMe();
  let cart = me.student.cart || [];
  const meId = me.student.id;

  const root = document.getElementById("cartRoot");
  const out = document.getElementById("cartMessage");
  const saveBtn = document.getElementById("saveCartBtn");

  // Get last simulation results to show enrollment status
  let enrolledCourses = new Set();
  let waitlistedCourses = new Set();
  try {
    const last = await API.lastSimulation();
    if (last.result) {
      const studentEnrollments = last.result.studentEnrollments?.[meId] || [];
      enrolledCourses = new Set(studentEnrollments);
      
      const studentWaitlists = last.result.studentWaitlists?.[meId] || [];
      waitlistedCourses = new Set(studentWaitlists);
    }
  } catch (e) {
    // Ignore if no simulation
  }

  // Load courses for schedule conflict checking
  const coursesResp = await API.listCourses("");
  const coursesMap = new Map(coursesResp.courses.map(c => [c.code, c]));

  function getScheduleConflicts(cartItems) {
    const conflicts = [];
    for (let i = 0; i < cartItems.length; i++) {
      for (let j = i + 1; j < cartItems.length; j++) {
        const course1 = coursesMap.get(cartItems[i].code);
        const course2 = coursesMap.get(cartItems[j].code);
        
        if (!course1 || !course2) continue;

        // Simple conflict check: same day, overlapping times
        const sched1 = course1.scheduleStrings[0] || "";
        const sched2 = course2.scheduleStrings[0] || "";
        
        if (sched1 && sched2 && sched1 !== sched2) {
          // Extract day and time
          const match1 = sched1.match(/(\w+)\s+(\d+):(\d+)-(\d+):(\d+)/);
          const match2 = sched2.match(/(\w+)\s+(\d+):(\d+)-(\d+):(\d+)/);
          
          if (match1 && match2) {
            const day1 = match1[1];
            const start1 = parseInt(match1[2]) * 60 + parseInt(match1[3]);
            const end1 = parseInt(match1[4]) * 60 + parseInt(match1[5]);
            
            const day2 = match2[1];
            const start2 = parseInt(match2[2]) * 60 + parseInt(match2[3]);
            const end2 = parseInt(match2[4]) * 60 + parseInt(match2[5]);

            if (day1 === day2 && start1 < end2 && start2 < end1) {
              conflicts.push({
                code1: cartItems[i].code,
                code2: cartItems[j].code,
                time1: sched1,
                time2: sched2
              });
            }
          }
        }
      }
    }
    return conflicts;
  }

  function render() {
    const conflicts = getScheduleConflicts(cart);
    const conflictWarning = conflicts.length > 0
      ? `
        <div class="card" style="border-left: 4px solid var(--red); background: rgba(255,0,0,0.05); margin-bottom: 16px;">
          <div style="font-weight:900; color:var(--red); font-size:16px;">⚠️ Ders Çakışmaları Tespit Edildi</div>
          <div class="small mt12">
            ${conflicts.map(c => `
              <div>
                <strong>${c.code1}</strong> (${c.time1}) ile 
                <strong>${c.code2}</strong> (${c.time2}) çakışıyor
              </div>
            `).join("")}
          </div>
          <div class="small mt12" style="color:var(--muted);">
            💡 İpucu: Çakışan dersleri sırayla düzenleyin veya "Required" işareti kullanarak 
            simülasyon sırasında hangisinin tutulacağını belirtin.
          </div>
        </div>
      `
      : "";

    root.innerHTML = conflictWarning + `
      <table class="table">
        <thead><tr><th>Sıra</th><th>Ders</th><th>Durum</th><th>Required</th><th>İşlem</th></tr></thead>
        <tbody>
          ${cart.map((it, idx) => {
            let statusBadge = "⭕ Kaydedilmedi";
            let statusStyle = "color: var(--muted);";
            
            if (enrolledCourses.has(it.code)) {
              statusBadge = "✅ Kaydedildi";
              statusStyle = "color: var(--green); font-weight: 900;";
            } else if (waitlistedCourses.has(it.code)) {
              statusBadge = "⏳ Waitlist";
              statusStyle = "color: var(--warning); font-weight: 900;";
            }
            
            return `
            <tr>
              <td>${idx + 1}</td>
              <td style="font-weight:800">${it.code}</td>
              <td style="${statusStyle}">${statusBadge}</td>
              <td>
                <input type="checkbox" ${it.required ? "checked" : ""} data-idx="${idx}" class="reqChk"/>
              </td>
              <td class="row">
                <button class="btn btn-secondary upBtn" data-idx="${idx}">↑</button>
                <button class="btn btn-secondary downBtn" data-idx="${idx}">↓</button>
                <button class="btn btn-secondary delBtn" data-idx="${idx}">Sil</button>
              </td>
            </tr>
          `;
          }).join("")}
        </tbody>
      </table>
      <div class="small mt12" style="margin-top: 20px;">
        <strong>Durum Açıklaması:</strong><br/>
        <span style="color: var(--green);">✅ Kaydedildi</span> - Simülasyonda başarıyla kaydoldunuz<br/>
        <span style="color: var(--warning);">⏳ Waitlist</span> - Kontenjan dolu, bekleme listesinesiniz<br/>
        <span style="color: var(--muted);">⭕ Kaydedilmedi</span> - Henüz simülasyon yapılmamış ya da kabul edilmedi
      </div>
      <div class="small mt12">Not: Zorunlu ders kod listesi ayrıca sistemde sabittir; burada required işareti de çakışma çözümünde etkili olur.</div>
    `;

    root.querySelectorAll(".reqChk").forEach(el => {
      el.addEventListener("change", () => {
        const idx = Number(el.dataset.idx);
        cart[idx].required = el.checked;
        render(); // Re-render to update conflict warnings
      });
    });

    root.querySelectorAll(".upBtn").forEach(b => b.addEventListener("click", () => {
      const i = Number(b.dataset.idx);
      if (i <= 0) return;
      [cart[i-1], cart[i]] = [cart[i], cart[i-1]];
      render();
    }));

    root.querySelectorAll(".downBtn").forEach(b => b.addEventListener("click", () => {
      const i = Number(b.dataset.idx);
      if (i >= cart.length - 1) return;
      [cart[i+1], cart[i]] = [cart[i], cart[i+1]];
      render();
    }));

    root.querySelectorAll(".delBtn").forEach(b => b.addEventListener("click", () => {
      const i = Number(b.dataset.idx);
      cart.splice(i, 1);
      render();
    }));
  }

  saveBtn.addEventListener("click", async () => {
    // normalize ranks
    cart = cart.map((x, idx) => ({ ...x, rank: idx }));
    try {
      await API.saveCart(cart);
      out.innerHTML = `<div class="card" style="background: var(--success-bg); border: 1px solid var(--success-border); color: var(--success-text);">
        <div style="font-weight:900; font-size:18px;">✅ Sepet kaydedildi</div>
        <div class="small mt12">Değişikliklerin kaydedilmişdir. Simülasyon sırasında bu sırayla işleme alınacak.</div>
      </div>`;
      setTimeout(() => { out.innerHTML = ""; }, 4000);
    } catch (e) {
      out.innerHTML = `<div class="card" style="color:var(--error);">❌ Kaydetme hatası: ${e.message}</div>`;
    }
  });

  render();
}

async function initSimulate() {
  const role = localStorage.getItem("role");
  const runBtn = document.getElementById("runBtn");
  const resetBtn = document.getElementById("resetBtn");
  const out = document.getElementById("simOut");

  if (role !== "admin") {
    out.innerHTML = `<div class="card">Bu sayfa sadece admin içindir. <a href="/login.html">Giriş yap</a></div>`;
    runBtn.disabled = true;
    resetBtn.disabled = true;
    return;
  }

  resetBtn.addEventListener("click", async () => {
    resetBtn.disabled = true;
    resetBtn.textContent = "Sıfırlanıyor...";
    try {
      const r = await API.resetSimulation();
      out.innerHTML = `
        <div class="card" style="background: var(--info-bg); border: 1px solid var(--info-border); color: var(--info-text);">
          <div style="font-weight:900; font-size:18px;">🔄 Veriler sıfırlandı</div>
          <div class="small mt12">Tüm öğrenciler başlangıç durumuna döndü. Yeni rasgele veriler oluşturulacak.</div>
          <div class="small mt12">Simülasyonu yeniden başlatabilirsiniz.</div>
        </div>
      `;
    } catch (e) {
      out.innerHTML = `<div class="card" style="color:var(--error);">Hata: ${e.message}</div>`;
    } finally {
      resetBtn.disabled = false;
      resetBtn.textContent = "🔄 Sıfırla";
    }
  });

  runBtn.addEventListener("click", async () => {
    runBtn.disabled = true;
    runBtn.textContent = "Çalışıyor...";
    try {
      const r = await API.runSimulation();
      const m = r.result.metrics;
      out.innerHTML = `
        <div class="card">
          <div style="font-weight:900; font-size:18px;">✅ Simülasyon tamamlandı</div>
          <div class="small mt12" style="color: var(--green); font-weight:900;">
            🔄 Her tıklamada farklı veriler üstünden işleme yapılıyor (Random)
          </div>
          
          <div class="small mt12"><strong>Genel Metrikler:</strong></div>
          <ul class="small">
            <li>Toplam talep edilen ders: ${m.totalDemanded}</li>
            <li>Toplam onaylanan ders: ${m.totalApproved}</li>
            <li>Genel başarı oranı: %${m.overallSuccessRate}</li>
            <li>Zorunlu ders başarı oranı: %${m.mandatoryCourseSuccessRate}</li>
            <li>Öğrenci başına ortalama alınan ders: ${m.avgApprovedPerStudent}</li>
          </ul>
          <div class="small mt12"><strong>Reddi Sebepleri:</strong></div>
          <ul class="small">
            <li>Kontenjanı dolan ders: ${m.fullCoursesCount}</li>
            <li>Kontenjan nedeniyle reddedilen: ${m.rejectedByCapacity}</li>
            <li>Waitlist'e alınan: ${m.waitlistedCount || 0}</li>
            <li>Çakışma nedeniyle reddedilen: ${m.rejectedByConflict}</li>
            <li>Çakışma çözümünde düşen ders: ${m.droppedDueToConflict || 0}</li>
            <li>Ön şart nedeniyle reddedilen: ${m.rejectedByPrereq}</li>
          </ul>
          <div class="small mt12" style="color: var(--muted);">Not: Sonuçlar dashboard'a yansıdı.</div>
          
          <div class="mt12">
            <a href="/dashboard.html" class="btn" style="display:inline-block;">
              📊 Detaylı Sonuçları Gör (Dashboard)
            </a>
          </div>
        </div>
      `;
    } catch (e) {
      out.innerHTML = `<div class="card">Hata: ${e.message}</div>`;
    } finally {
      runBtn.disabled = false;
      runBtn.textContent = "Simülasyonu Başlat";
    }
  });
}

async function initAdmin() {
  const role = localStorage.getItem("role");
  const root = document.getElementById("adminRoot");

  if (role !== "admin") {
    root.innerHTML = `<div class="card">Bu sayfa sadece admin içindir. <a href="/login.html">Giriş yap</a></div>`;
    return;
  }

  const form = document.getElementById("addCourseForm");
  const list = document.getElementById("adminCourseList");

  async function load() {
    const r = await API.adminCourses();
    list.innerHTML = `
      <table class="table">
        <thead>
          <tr><th>Kod</th><th>Ad</th><th>Bölüm</th><th>Kontenjan</th><th>Doluluk</th><th>Zorunlu</th><th></th></tr>
        </thead>
        <tbody>
          ${r.courses.map(c => `
            <tr>
              <td style="font-weight:900">${c.code}</td>
              <td>${c.name}</td>
              <td>${c.dept}</td>
              <td>${c.capacity}</td>
              <td>${c.enrolled}/${c.capacity} · WL:${c.waitlist}</td>
              <td>${c.mandatory ? "Evet" : "Hayır"}</td>
              <td><button class="btn btn-secondary delAdminBtn" data-code="${c.code}">Sil</button></td>
            </tr>
          `).join("")}
        </tbody>
      </table>
    `;

    list.querySelectorAll(".delAdminBtn").forEach(b => b.addEventListener("click", async () => {
      const code = b.dataset.code;
      if (!confirm(code + " silinsin mi?")) return;
      try {
        await API.adminDeleteCourse(code);
        await load();
      } catch (e) {
        alert("Silme hatası: " + e.message);
      }
    }));
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const course = {
      code: document.getElementById("c_code").value.trim(),
      name: document.getElementById("c_name").value.trim(),
      dept: document.getElementById("c_dept").value.trim(),
      capacity: Number(document.getElementById("c_capacity").value),
      scheduleStrings: [document.getElementById("c_sched").value.trim()],
      prereqs: document.getElementById("c_prereq").value.trim()
        ? document.getElementById("c_prereq").value.trim().split(",").map(s => s.trim())
        : []
    };

    try {
      await API.adminAddCourse(course);
      form.reset();
      await load();
    } catch (e2) {
      alert("Ekleme hatası: " + e2.message);
    }
  });

  await load();
}

async function initTranscript() {
  const role = localStorage.getItem("role");
  const studentId = localStorage.getItem("studentId");
  const content = document.getElementById("transcriptContent");

  if (role !== "student") {
    content.innerHTML = `<div class="card">Bu sayfa sadece öğrenciler içindir. <a href="/login.html">Giriş yap</a></div>`;
    return;
  }

  // Get student's completed courses from simulate result
  const last = await API.lastSimulation();
  const result = last.result;

  if (!result) {
    content.innerHTML = `<div class="card"><div class="small">Henüz simülasyon çalıştırılmadı.</div></div>`;
    return;
  }

  // Get me's data
  const myData = (result.students || []).find(s => s.id === studentId);

  if (!myData) {
    content.innerHTML = `<div class="card"><div class="small">Transkript verisi bulunamadı.</div></div>`;
    return;
  }

  // Get all courses for reference
  const allCourses = result.courses || [];
  const coursesMap = new Map(allCourses.map(c => [c.code, c]));

  // Render profile section
  const profileHTML = `
    <div class="card">
      <div style="font-weight:900; font-size:18px;">Öğrenci Bilgileri</div>
      <div class="small mt12">
        <div><strong>ID:</strong> ${myData.id}</div>
        <div><strong>Sınıf:</strong> ${myData.classYear}. Sınıf</div>
        <div><strong>GPA:</strong> ${myData.gpa.toFixed(2)}</div>
        <div><strong>Mezuniyete Kalan Ders:</strong> ${myData.remainingCourses}</div>
      </div>
    </div>
  `;

  // Render approved courses
  const approved = myData.approved || [];
  const approvedHTML = `
    <div class="card mt12">
      <div style="font-weight:900; font-size:18px;">✅ Tamamlanan Dersler (${approved.length})</div>
      ${approved.length === 0 
        ? `<div class="small mt12">Henüz derse kaydolmadınız.</div>`
        : `
          <table class="table mt12">
            <thead>
              <tr><th>Ders Kodu</th><th>Ders Adı</th><th>Bölüm</th><th>Kontenjan</th></tr>
            </thead>
            <tbody>
              ${approved.map(code => {
                const course = coursesMap.get(code);
                return `
                  <tr>
                    <td style="font-weight:900">${code}</td>
                    <td>${course ? course.name : "Bilinmiyor"}</td>
                    <td>${course ? course.dept : "-"}</td>
                    <td>${course ? course.capacity : "-"}</td>
                  </tr>
                `;
              }).join("")}
            </tbody>
          </table>
        `
      }
    </div>
  `;

  // Render rejected courses
  const rejected = myData.rejected || [];
  const rejectedHTML = `
    <div class="card mt12">
      <div style="font-weight:900; font-size:18px;">❌ Reddedilen Dersler (${rejected.length})</div>
      ${rejected.length === 0 
        ? `<div class="small mt12">Tüm dersler başarıyla kaydoldunuz!</div>`
        : `
          <table class="table mt12">
            <thead>
              <tr><th>Ders Kodu</th><th>Ders Adı</th><th>Red Sebebi</th></tr>
            </thead>
            <tbody>
              ${rejected.map(item => {
                const course = coursesMap.get(item.code);
                const reasonText = {
                  "COURSE_NOT_FOUND": "Ders bulunamadı",
                  "PREREQ_MISSING": "Ön şart eksik",
                  "CONFLICT": "Ders çakışması",
                  "CAPACITY_FULL": "Kontenjan dolu",
                  "CAPACITY_FULL_WAITLISTED": "Kontenjan dolu - Bekleme listesine alındı"
                }[item.reason] || item.reason;

                return `
                  <tr>
                    <td style="font-weight:900">${item.code}</td>
                    <td>${course ? course.name : "Bilinmiyor"}</td>
                    <td>${reasonText}</td>
                  </tr>
                `;
              }).join("")}
            </tbody>
          </table>
        `
      }
    </div>
  `;

  // Render summary
  const summaryHTML = `
    <div class="card mt12">
      <div style="font-weight:900; font-size:18px;">Özet</div>
      <div class="grid mt12">
        <div class="card" style="grid-column: span 4;">
          <div class="kpi">
            <div class="value">${approved.length}</div>
            <div class="label">Başarılı Ders</div>
          </div>
        </div>
        <div class="card" style="grid-column: span 4;">
          <div class="kpi">
            <div class="value">${rejected.length}</div>
            <div class="label">Başarısız Ders</div>
          </div>
        </div>
        <div class="card" style="grid-column: span 4;">
          <div class="kpi">
            <div class="value">${approved.length + rejected.length}</div>
            <div class="label">Toplam Talep</div>
          </div>
        </div>
      </div>
    </div>
  `;

  content.innerHTML = profileHTML + approvedHTML + rejectedHTML + summaryHTML;
}

async function initWaitlist() {
  const meId = localStorage.getItem("studentId");
  const role = localStorage.getItem("role");
  const container = document.getElementById("waitlistContainer");

  if (role !== "student") {
    container.innerHTML = `<div class="card">Bu sayfa sadece öğrenciler için. <a href="/login.html">Giriş yap</a></div>`;
    return;
  }

  try {
    // Get student's waitlist from backend
    const myWaitlist = await API.getMyWaitlist();
    const waitlistedCourses = myWaitlist.waitlist || [];

    if (waitlistedCourses.length === 0) {
      container.innerHTML = `
        <div class="card" style="background: var(--success-bg); border: 1px solid var(--success-border); color: var(--success-text);">
          <div style="font-weight:900;">✅ Waitlist'de dersiniz yok</div>
          <div class="small mt12">Tüm kayıt talebiniz kabul edilmiştir.</div>
        </div>
      `;
      return;
    }

    let html = `
      <div class="card">
        <div style="font-weight:900; color: var(--warning);">⏳ Bekleme Listesi (${waitlistedCourses.length} ders)</div>
        <div class="small mt12">Bu dersler kapasitesi dolu. Simülasyonda kontenjan boşalırsa otomatik olarak kaydolabilirsiniz.</div>
        <div class="mt12">
          <ul class="small">
    `;

    for (const course of waitlistedCourses) {
      html += `<li><strong>${course.code}</strong> - ${course.name}<br/><span style="color: var(--muted); font-size: 12px;">Sıra: ${course.waitlistPosition}/${course.waitlistTotal}</span></li>`;
    }

    html += `
          </ul>
        </div>
      </div>
    `;

    container.innerHTML = html;
  } catch (err) {
    container.innerHTML = `<div class="card">Hata: ${err.message}</div>`;
  }
}

