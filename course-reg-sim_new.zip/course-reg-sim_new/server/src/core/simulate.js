import { explainMissingPrereqsForCourse } from "./prereq.js";
import { findConflicts } from "./conflict.js";
import { sortStudentsByPriority } from "./priority.js";
import { createMetrics, finalizeMetrics } from "./metrics.js";
import { addToWaitlist, processWaitlistAutoEnroll } from "./waitlist.js";

/**
 * Deterministic RNG (Mulberry32)
 * Her simülasyon farklı seed kullanır = farklı veriler
 */
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function sampleUnique(rng, arr, k) {
  const copy = arr.slice();
  // Fisher-Yates partial shuffle
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy.slice(0, Math.min(k, copy.length));
}

function pick(rng, arr) {
  return arr[Math.floor(rng() * arr.length)];
}

/**
 * Her simülasyon başında random ders sepeti oluştur
 * - Her öğrenci için rasgele 3-8 ders seçer
 * - Rasgele required işareti ekler
 */
function generateRandomCarts(rng, store) {
  const courseCodes = Array.from(store.coursesByCode.keys());
  const requiredCodes = Array.from(store.requiredCourseCodes);
  
  for (const student of store.students.values()) {
    // Rasgele 3-8 ders
    const cartSize = 3 + Math.floor(rng() * 6);
    const selectedCodes = sampleUnique(rng, courseCodes, cartSize);
    
    // Yeni cart oluştur
    const newCart = selectedCodes.map((code, idx) => {
      // %20 ihtimalle required işareti
      const isRequired = rng() < 0.2;
      return { code, required: isRequired, rank: idx };
    });
    
    // Bazen zorunlu ders ekleme (daha realistic)
    if (rng() < 0.3 && requiredCodes.length > 0) {
      const reqCode = pick(rng, requiredCodes);
      if (!newCart.some(x => x.code === reqCode)) {
        newCart.unshift({ code: reqCode, required: true, rank: -1 });
      }
    }
    
    // Normalize ranks
    newCart.forEach((item, idx) => { item.rank = idx; });
    
    student.cart = newCart;
  }
}

function isCourseMandatory(store, courseCode) {
  return store.requiredCourseCodes.has(courseCode);
}

function isRequestedRequired(cartItem) {
  return !!cartItem.required;
}

export function runSimulation(store) {
  // DÜZELTME: Daha güçlü random seed (Math.random() + timestamp)
  // Her çalıştırmada garantili farklı olacak
  const randomSeed = Math.floor(Math.random() * 2147483647);
  const rng = mulberry32(randomSeed);
  
  // Öğrencilerin sepetlerini rasgele yeniden oluştur
  generateRandomCarts(rng, store);
  
  // Reset enrollments + waitlists each run (RAM-based simulation)
  for (const c of store.coursesByCode.values()) {
    c.enrolledStudentIds = new Set();
    c.waitlistStudentIds = [];
  }

  const studentsArr = Array.from(store.students.values());
  sortStudentsByPriority(studentsArr);

  const metrics = createMetrics();
  const results = [];

  for (const student of studentsArr) {
    const approved = [];
    const rejected = [];
    const scheduleAccum = []; // list of schedule blocks of approved
    const thisTermRequested = new Set(); // co-requisite: approved + in-progress
    // Pre-fill with cart codes? (same term counts) -> allow prereq if it exists anywhere in cart
    // We'll add all cart codes here so prereqs count if they are in cart, even if later approved.
    for (const item of student.cart || []) thisTermRequested.add(item.code);

    for (const item of (student.cart || [])) {
      const code = item.code;
      const course = store.coursesByCode.get(code);
      if (!course) {
        rejected.push({ code, reason: "COURSE_NOT_FOUND" });
        continue;
      }

      // 1) prereq chain
      const prereqExplain = explainMissingPrereqsForCourse(
        store,
        code,
        student.completedCourses || new Set(),
        thisTermRequested
      );
      if (prereqExplain.missing.length) {
        metrics.rejectedByPrereq++;
        rejected.push({
          code,
          reason: "PREREQ_MISSING",
          detail: prereqExplain
        });
        continue;
      }

      // 2) conflict check
      const conflicts = findConflicts(scheduleAccum, course.schedule);
      if (conflicts.length) {
        // conflict resolution rule:
        // - mandatory (code list) always stays
        // - else user-required stays
        // - if both mandatory -> cart order wins (existing approved stays, new rejected)
        // Here we treat "existing approved" as already chosen; new one tries to enter.

        const newIsMandatory = isCourseMandatory(store, code);
        const newIsReq = newIsMandatory || isRequestedRequired(item);

        // find a conflicting approved course code (first one)
        const conflictingApproved = findFirstConflictingApproved(store, approved, course);
        if (conflictingApproved) {
          const oldCode = conflictingApproved;
          const oldMandatory = isCourseMandatory(store, oldCode);
          const oldReq = oldMandatory || isStudentMarkedRequired(student, oldCode);

          // Decide keep which:
          // If old mandatory and new mandatory -> keep old (because it came earlier in cart)
          if (oldMandatory && newIsMandatory) {
            metrics.rejectedByConflict++;
            rejected.push({ code, reason: "CONFLICT_REQUIRED_REQUIRED", detail: { with: oldCode, conflicts } });
            continue;
          }

          // If new is mandatory/required and old is not, drop old
          if (newIsReq && !oldReq) {
            // drop old
            dropApprovedCourse(store, student, approved, scheduleAccum, oldCode);
            metrics.rejectedByConflict++; // a conflict happened
            metrics.droppedDueToConflict++;

            rejected.push({
              code: oldCode,
              reason: "DROPPED_DUE_TO_CONFLICT",
              detail: { replacedBy: code }
            });
            // continue to capacity check & enroll new
          } else {
            // keep old, reject new
            metrics.rejectedByConflict++;
            rejected.push({ code, reason: "CONFLICT", detail: { with: oldCode, conflicts } });
            continue;
          }
        } else {
          // no mapping found -> reject safely
          metrics.rejectedByConflict++;
          rejected.push({ code, reason: "CONFLICT", detail: { conflicts } });
          continue;
        }
      }

      // 3) capacity
      if (course.enrolledStudentIds.size >= course.capacity) {
        metrics.rejectedByCapacity++;

        // Bonus policy: if the student explicitly marked it required (or it's mandatory), auto waitlist.
        const mustTry = isCourseMandatory(store, code) || isRequestedRequired(item);
        if (mustTry) {
          const wl = addToWaitlist(store, code, student.id);
          if (wl.ok) {
            metrics.waitlistedCount++;
            rejected.push({ code, reason: "CAPACITY_FULL_WAITLISTED" });
            continue;
          }
        }

        rejected.push({ code, reason: "CAPACITY_FULL", detail: { canWaitlist: true } });
        continue;
      }

      // 4) enroll
      course.enrolledStudentIds.add(student.id);
      approved.push(code);
      // add course schedule blocks
      for (const s of course.schedule) scheduleAccum.push(s);
      
      // 4a) Bonus: eğer kontenjan tam dolmuşsa, waitlist'ten otomatik kaydet
      if (course.enrolledStudentIds.size === course.capacity) {
        processWaitlistAutoEnroll(store, code);
      }
    }

    results.push({
      id: student.id,
      classYear: student.classYear,
      remainingCourses: student.remainingCourses,
      gpa: student.gpa,
      approved,
      rejected,
      totalDemanded: approved.length + rejected.length,
      successCount: approved.length
    });
  }

  finalizeMetrics(metrics, store, results);

  // Öğrenci enrollment'ları ve waitlist'lerini haritalandır
  const studentEnrollments = {};
  const studentWaitlists = {};
  
  for (const student of store.students.values()) {
    studentEnrollments[student.id] = [];
    studentWaitlists[student.id] = [];
  }
  
  // Her kurs için öğrenci ID'lerini kayıt et
  for (const course of store.coursesByCode.values()) {
    for (const studentId of course.enrolledStudentIds) {
      if (!studentEnrollments[studentId]) studentEnrollments[studentId] = [];
      studentEnrollments[studentId].push(course.code);
    }
    for (const studentId of course.waitlistStudentIds) {
      if (!studentWaitlists[studentId]) studentWaitlists[studentId] = [];
      studentWaitlists[studentId].push(course.code);
    }
  }

  const summary = {
    metrics,
    students: results,
    courses: Array.from(store.coursesByCode.values()).map(c => ({
      code: c.code,
      name: c.name,
      dept: c.dept,
      capacity: c.capacity,
      enrolled: c.enrolledStudentIds.size,
      waitlist: c.waitlistStudentIds.length,
      fillRate: c.capacity ? Math.round((c.enrolledStudentIds.size / c.capacity) * 100) / 100 : 0
    })),
    studentEnrollments,
    studentWaitlists
  };

  store.lastSimulation = summary;
  return summary;
}

function findFirstConflictingApproved(store, approvedCodes, newCourse) {
  for (const code of approvedCodes) {
    const old = store.coursesByCode.get(code);
    if (!old) continue;
    const conflicts = findConflicts(old.schedule, newCourse.schedule);
    if (conflicts.length) return code;
  }
  return null;
}

function isStudentMarkedRequired(student, courseCode) {
  const item = (student.cart || []).find(x => x.code === courseCode);
  return !!(item && item.required);
}

function dropApprovedCourse(store, student, approved, scheduleAccum, oldCode) {
  // remove from approved list
  const idx = approved.indexOf(oldCode);
  if (idx >= 0) approved.splice(idx, 1);

  // remove schedule blocks of old course from scheduleAccum (rebuild for safety)
  const rebuilt = [];
  for (const code of approved) {
    const c = store.coursesByCode.get(code);
    if (!c) continue;
    for (const s of c.schedule) rebuilt.push(s);
  }
  scheduleAccum.length = 0;
  for (const s of rebuilt) scheduleAccum.push(s);

  // remove enrollment
  const oldCourse = store.coursesByCode.get(oldCode);
  if (oldCourse) oldCourse.enrolledStudentIds.delete(student.id);
}
