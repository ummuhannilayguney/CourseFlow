export function addToWaitlist(store, courseCode, studentId) {
  console.log(`[WAITLIST] Adding student ${studentId} to waitlist of course ${courseCode}`);
  
  const course = store.coursesByCode.get(courseCode);
  if (!course) {
    console.log(`[WAITLIST] Course not found: ${courseCode}`);
    return { ok: false, error: "COURSE_NOT_FOUND" };
  }

  // already enrolled?
  if (course.enrolledStudentIds.has(studentId)) {
    console.log(`[WAITLIST] Student ${studentId} already enrolled in ${courseCode}`);
    return { ok: false, error: "ALREADY_ENROLLED" };
  }

  // already waitlisted?
  if (course.waitlistStudentIds.includes(studentId)) {
    console.log(`[WAITLIST] Student ${studentId} already waitlisted for ${courseCode}`);
    return { ok: false, error: "ALREADY_WAITLISTED" };
  }

  course.waitlistStudentIds.push(studentId);
  console.log(`[WAITLIST] Successfully added student ${studentId} to ${courseCode}. Waitlist now: ${JSON.stringify(course.waitlistStudentIds)}`);
  return { ok: true };
}

/**
 * Processus otomatik kay{ıt: kontenjan boşaldığında waitlist'in ilk öğrencisini kaydettir
 */
export function processWaitlistAutoEnroll(store, courseCode) {
  const course = store.coursesByCode.get(courseCode);
  if (!course || course.waitlistStudentIds.length === 0) {
    return null; // no one to enroll
  }

  // Eğer kontenjan hala dolu ise, yapma
  if (course.enrolledStudentIds.size >= course.capacity) {
    return null;
  }

  // En eski waitlist'ten öğrenciyi çıkar ve kaydet
  const studentId = course.waitlistStudentIds.shift(); // FIFO: ilk kişi
  course.enrolledStudentIds.add(studentId);
  
  return { enrolledStudentId: studentId };
}
