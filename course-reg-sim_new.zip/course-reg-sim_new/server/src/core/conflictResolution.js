/**
 * Çakışma çözümleme stratejileri
 * Sistem automatikten önce, kullanıcı seçim yapabilmelidir
 */

export const ConflictResolutionStrategies = {
  KEEP_OLD: "KEEP_OLD",           // Yeni dersi reddet, eski dersi koru
  KEEP_NEW: "KEEP_NEW",           // Eski dersi bırak, yeni dersi al
  KEEP_REQUIRED: "KEEP_REQUIRED"  // Zorunlu/required olanı tut
};

/**
 * Strateji açıklaması
 */
export function getStrategyDescription(strategy) {
  const descriptions = {
    [ConflictResolutionStrategies.KEEP_OLD]: "Yeni dersi reddet, eski dersi tut",
    [ConflictResolutionStrategies.KEEP_NEW]: "Eski dersi bırak, yeni dersi al",
    [ConflictResolutionStrategies.KEEP_REQUIRED]: "Zorunlu/gerekli dersi tut, diğerini bırak"
  };
  return descriptions[strategy] || "Bilinmeyen strateji";
}
