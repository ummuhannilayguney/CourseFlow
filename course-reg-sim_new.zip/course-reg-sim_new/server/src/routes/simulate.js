import express from "express";
import { requireAuth } from "../config/auth.js";
import { runSimulation } from "../core/simulate.js";
import { seedStudents } from "../data/seedStudents.js";

const router = express.Router();

// Admin triggers simulation (or allow student too if you want, for now admin)
router.post("/run", requireAuth("admin"), (req, res) => {
  const store = req.app.locals.store;
  const result = runSimulation(store);
  res.json({ ok: true, result });
});

router.get("/last", (req, res) => {
  const store = req.app.locals.store;
  res.json({ ok: true, result: store.lastSimulation });
});

/**
 * YENI: Reset endpoint
 * Öğrencilerin cart'larını orijinal haline geri getir
 * Bu sayede "Sıfırla" tuşuna basılınca yeni rasgele veriler oluşturulur
 */
router.post("/reset", requireAuth("admin"), (req, res) => {
  try {
    const store = req.app.locals.store;
    
    // Öğrencileri yeniden seed et (orijinal cart'larla)
    store.students = seedStudents({
      count: 1000,
      courseCodes: Array.from(store.coursesByCode.keys()),
      requiredCourseCodes: store.requiredCourseCodes,
      testStudent: {
        id: process.env.TEST_STUDENT_ID || "S0001",
        password: process.env.TEST_STUDENT_PASSWORD || "student123"
      }
    });
    
    // Enrollment'ları da sıfırla
    for (const c of store.coursesByCode.values()) {
      c.enrolledStudentIds = new Set();
      c.waitlistStudentIds = [];
    }
    
    // Son simülasyon sonucunu sil
    store.lastSimulation = null;
    
    res.json({ ok: true, message: "Öğrenciler sıfırlandı. Yeni rasgele veriler oluşturulacak." });
  } catch (err) {
    console.error("Reset error:", err);
    res.status(500).json({ error: "INTERNAL_SERVER_ERROR", detail: err.message });
  }
});

export default router;

