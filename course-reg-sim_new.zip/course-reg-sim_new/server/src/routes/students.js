import express from "express";
import { requireAuth } from "../config/auth.js";
import { addToWaitlist } from "../core/waitlist.js";

const router = express.Router();

// Student profile (test student)
router.get("/me", requireAuth("student"), (req, res) => {
  const store = req.app.locals.store;
  const student = store.students.get(req.user.id);
  if (!student) return res.status(404).json({ ok: false, error: "STUDENT_NOT_FOUND" });

  res.json({
    ok: true,
    student: {
      id: student.id,
      firstName: student.firstName,
      lastName: student.lastName,
      email: student.email,
      classYear: student.classYear,
      remainingCourses: student.remainingCourses,
      gpa: student.gpa,
      special: student.special,
      cart: student.cart
    }
  });
});

// Update cart: replace whole cart (simple)
router.post("/me/cart", requireAuth("student"), (req, res) => {
  const store = req.app.locals.store;
  const student = store.students.get(req.user.id);
  if (!student) return res.status(404).json({ ok: false, error: "STUDENT_NOT_FOUND" });

  const { cart } = req.body || {};
  if (!Array.isArray(cart)) return res.status(400).json({ ok: false, error: "BAD_CART" });

  // validate
  for (const item of cart) {
    if (!item || typeof item.code !== "string") {
      return res.status(400).json({ ok: false, error: "BAD_CART_ITEM" });
    }
  }

  student.cart = cart.map((x, idx) => ({
    code: x.code,
    required: !!x.required,
    rank: Number.isFinite(x.rank) ? x.rank : idx
  }));

  res.json({ ok: true, cart: student.cart });
});

// Add to waitlist (user clicks button after capacity full)
router.post("/me/waitlist", requireAuth("student"), (req, res) => {
  const store = req.app.locals.store;
  const { courseCode } = req.body || {};
  if (!courseCode) return res.status(400).json({ ok: false, error: "BAD_REQUEST" });

  const r = addToWaitlist(store, courseCode, req.user.id);
  if (!r.ok) return res.status(400).json(r);

  res.json({ ok: true });
});

// Get student's waitlist courses
router.get("/me/waitlist", requireAuth("student"), (req, res) => {
  const store = req.app.locals.store;
  const studentId = req.user.id;
  
  console.log(`[GET WAITLIST] Fetching waitlist for student ${studentId}`);
  
  const waitlistedCourses = [];
  for (const course of store.coursesByCode.values()) {
    console.log(`[GET WAITLIST] Checking ${course.code}, waitlist: ${JSON.stringify(course.waitlistStudentIds)}`);
    if (course.waitlistStudentIds.includes(studentId)) {
      waitlistedCourses.push({
        code: course.code,
        name: course.name,
        waitlistPosition: course.waitlistStudentIds.indexOf(studentId) + 1,
        waitlistTotal: course.waitlistStudentIds.length
      });
    }
  }
  
  console.log(`[GET WAITLIST] Found ${waitlistedCourses.length} waitlisted courses for student ${studentId}: ${JSON.stringify(waitlistedCourses)}`);
  res.json({ ok: true, waitlist: waitlistedCourses });
});

export default router;
